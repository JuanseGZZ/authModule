// Utilities for login page (reserved for future transforms)
export const loginUtils = Object.freeze({});
