// Utilities for register page (reserved for future transforms)
export const registerUtils = Object.freeze({});
