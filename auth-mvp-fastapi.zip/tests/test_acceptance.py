import pytest

# Solo stubs de aceptación (para que otro LLM implemente E2E)
def test_register_ok():
    assert True

def test_login_ok():
    assert True

def test_refresh_ok():
    assert True

def test_me_ok():
    assert True
